﻿#===================================================================#
# T  R  A  I  N  I  N  G                                            #
#                   Course:         PowerShell Fundamentals         #
#    ¯\_(ツ)_/¯     Created by:     Paweł Dremel                    #
#                   Created on:     08.10.2021                      #
#                   Organization:   https://www.altkomakademia.pl   #
#                                                                   #
#===================================================================#

function Get-DemoLogicalDisk {
    param(
        [string]$ComputerName=(Read-Host "Enter computer name")
    )
    Get-CimInstance Win32_LogicalDisk -ComputerName $ComputerName -Filter "DriveType=3"
}
function Get-DemoOperatingSystem {
    param(
        [string]$ComputerName=(Read-Host "Enter computer name")
    )
    Get-CimInstance -ClassName Win32_OperatingSystem -ComputerName $ComputerName
}