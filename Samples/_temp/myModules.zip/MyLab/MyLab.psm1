﻿#===================================================================#
# T  R  A  I  N  I  N  G                                            #
#                   Course:         PowerShell Fundamentals         #
#    ¯\_(ツ)_/¯     Created by:     Paweł Dremel                    #
#                   Created on:     08.10.2021                      #
#                   Organization:   https://www.altkomakademia.pl   #
#                                                                   #
#===================================================================#

function Get-DemoComputerSystem {
    param(
        [string]$ComputerName=(Read-Host "Enter computer name")
    )
    Get-CimInstance Win32_ComputerSystem -ComputerName $ComputerName
}
function Get-DemoBios {
    param(
        [string]$ComputerName=(Read-Host "Enter computer name")
    )
    Get-CimInstance -ClassName Win32_Bios -ComputerName $ComputerName
}