﻿#===================================================================#
# T  R  A  I  N  I  N  G                                            #
#                   Course:         PowerShell Fundamentals         #
#    ¯\_(ツ)_/¯     Created by:     Paweł Dremel                    #
#                   Created on:     08.10.2021                      #
#                   Organization:   https://www.altkomakademia.pl   #
#                                                                   #
#===================================================================#

function New-MyPipeline {
    param (
        [string[]]$MyInput = (Read-Host "wpisz cos do New")
    )
    foreach ($My in $MyInput) {
        $Properties = [ordered]@{
            'MyInput' = $My
        }
        $Object = New-Object -TypeName psobject -Property $Properties
        $Object
    }
    Write-Host "Koncze: New-MyPipeline" -ForegroundColor Green
}

function Add-MyPipeline {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true,
            ValueFromPipeline = $true,
            ValueFromPipelineByPropertyName = $true)]
        [string[]]$MyInput
    )

    process {
        foreach ($My in $MyInput) {
            Write-Host "Add Odebralem: $My" -ForegroundColor Green
            $var = Read-Host "wpisz cos do Add"
            $Properties = [ordered]@{
                'MyInput' = $My
                'MyAdd'   = $var
            }
            $Object = New-Object -TypeName psobject -Property $Properties
            $Object
        }
    }
    end {
        Write-Host "Koncze: Add-MyPipeline" -ForegroundColor Green
    }
}
