# Databricks notebook source
# MAGIC %sql
# MAGIC USE CATALOG dbc_diab_stg_ead_aen_gold_001;
# MAGIC USE SCHEMA sample_schema;
# MAGIC  
# MAGIC SELECT * FROM sample_employees;