# Databricks notebook source
dbutils.secrets.listScopes()

# COMMAND ----------

eh_namespace = "evhns-diab-stg-ead-aen-001"
eh_instance_name = "evh-evhns-diab-stg-ead-aen-001"
eh_connection_string = dbutils.secrets.get(scope='dbs-diab-stg-ead-aen-001', key='kvs-diab-stg-ead-eh-dbx-conn-aen-001')

# COMMAND ----------

eh_options = {
  "kafka.bootstrap.servers": f"{eh_namespace}.servicebus.windows.net:9093",
  "subscribe": eh_instance_name,
  "kafka.sasl.mechanism": "PLAIN",
  "kafka.security.protocol": "SASL_SSL",
  "kafka.sasl.jaas.config": f"kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username=\"$ConnectionString\" password=\"{eh_connection_string}\";",
  "failOnDataLoss": "false"
}

# COMMAND ----------

df = spark.readStream.format("kafka").options(**eh_options).load()

# COMMAND ----------

df.display()

# COMMAND ----------

!nslookup evhns-diab-stg-ead-aen-001.servicebus.windows.net