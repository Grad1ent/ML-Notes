# Databricks notebook source
display(dbutils.fs.ls("abfss://bronze@dlsstgeadaen001.dfs.core.windows.net/"))