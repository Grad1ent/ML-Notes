# Databricks notebook source
# MAGIC %sql
# MAGIC USE CATALOG dbc_diab_stg_ead_aen_gold_001;
# MAGIC USE SCHEMA sample_schema;
# MAGIC  
# MAGIC DELETE FROM sample_employees;