# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC USE CATALOG dbc_diab_stg_eca_aen_gold_001;
# MAGIC USE SCHEMA sample_schema;
# MAGIC  
# MAGIC INSERT INTO  sample_table_employees VALUES
# MAGIC   (1, 'Alice', 'Engineering', 95000),
# MAGIC   (2, 'Bob', 'Marketing', 72000),
# MAGIC   (3, 'Charlie', 'Finance', 80000);