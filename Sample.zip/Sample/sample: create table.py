# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC USE CATALOG dbc_diab_stg_eca_aen_gold_001;
# MAGIC
# MAGIC CREATE SCHEMA IF NOT EXISTS sample_schema;
# MAGIC USE SCHEMA sample_schema;
# MAGIC  
# MAGIC CREATE TABLE IF NOT EXISTS sample_table_employees (
# MAGIC   id INT,
# MAGIC   name STRING,
# MAGIC   department STRING,
# MAGIC   salary INT
# MAGIC );