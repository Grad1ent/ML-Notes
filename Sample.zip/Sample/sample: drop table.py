# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC USE CATALOG dbc_diab_stg_eca_aen_gold_001;
# MAGIC USE SCHEMA sample_schema;
# MAGIC  
# MAGIC DROP TABLE IF EXISTS sample_table_employees;