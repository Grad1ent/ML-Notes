# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.types import (
    StructType, StructField,
    IntegerType, StringType, BooleanType, TimestampType
)

spark = SparkSession.builder.getOrCreate()

# ---- configuration: set catalog/schema/table names ----
dbutils.widgets.text("catalog_name", "dbc_diab_stg_eca_aen_bronze_001")
dbutils.widgets.text("schema_name", "AdventureWorks")
dbutils.widgets.text("table_name", "Address")

catalog_name = dbutils.widgets.get("catalog_name")
schema_name = dbutils.widgets.get("schema_name")
table_name = dbutils.widgets.get("table_name")

spark.sql(f"USE CATALOG {catalog_name}")
spark.sql(f"DELETE FROM {schema_name}.{table_name}")