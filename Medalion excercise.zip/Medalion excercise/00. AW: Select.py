# Databricks notebook source
# MAGIC %sql
# MAGIC USE CATALOG dbc_diab_stg_eca_aen_gold_001;
# MAGIC -- USE CATALOG dbc_diab_stg_eca_aen_bronze_001;
# MAGIC USE SCHEMA adventureworks;
# MAGIC
# MAGIC SELECT * FROM superperson;
# MAGIC -- SELECT * FROM person;