# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.types import (
    StructType, StructField,
    IntegerType, StringType, BooleanType, TimestampType
)

# spark = SparkSession.builder.getOrCreate()

# ---- configuration: set catalog/schema/table names ----
dbutils.widgets.text("src_catalog_name", "dbc_diab_stg_eca_aen_silver_001")
dbutils.widgets.text("src_schema_name", "AdventureWorks")
dbutils.widgets.text("src_table_person", "Person")
dbutils.widgets.text("src_table_address", "Address")
dbutils.widgets.text("src_table_personaddress", "PersonAddress")

dbutils.widgets.text("dst_catalog_name", "dbc_diab_stg_eca_aen_gold_001")
dbutils.widgets.text("dst_schema_name", "AdventureWorks")
dbutils.widgets.text("dst_table_name", "SuperPerson")

src_catalog_name = dbutils.widgets.get("src_catalog_name")
src_schema_name = dbutils.widgets.get("src_schema_name")
src_table_person = dbutils.widgets.get("src_table_person")
src_table_address = dbutils.widgets.get("src_table_address")
src_table_personaddress = dbutils.widgets.get("src_table_personaddress")
src_full_table_person = f"{src_catalog_name}.{src_schema_name}.{src_table_person}"
src_full_table_address = f"{src_catalog_name}.{src_schema_name}.{src_table_address}"
src_full_table_personaddress = f"{src_catalog_name}.{src_schema_name}.{src_table_personaddress}"

dst_catalog_name = dbutils.widgets.get("dst_catalog_name")
dst_schema_name = dbutils.widgets.get("dst_schema_name")
dst_table_name = dbutils.widgets.get("dst_table_name")
dst_full_table_name = f"{dst_catalog_name}.{dst_schema_name}.{dst_table_name}"

# Read Silver tables
src_person_df = spark.table(src_full_table_person)
src_address_df = spark.table(src_full_table_address)
src_personaddress_df    = spark.table(src_full_table_personaddress)
#src_atype_df  = spark.table("aw.silver.dim_address_type")

# Perform denormalization join
gold_df = (src_person_df
    .join(src_personaddress_df, src_person_df.BusinessEntityID == src_personaddress_df.BusinessEntityID, "inner")
    .join(src_address_df, src_personaddress_df.AddressID == src_address_df.AddressID, "inner")
     #.join(atype_df, bea_df.AddressTypeID == atype_df.AddressTypeID, "inner")
    .select(
        #src_person_df.BusinessEntityID.alias("PersonID"),
        src_person_df.FirstName,
        src_person_df.MiddleName,
        src_person_df.LastName,
        src_person_df.PersonType,
        src_address_df.AddressID,
        src_address_df.AddressLine1,
        src_address_df.AddressLine2,
        src_address_df.City,
        src_address_df.PostalCode
        #atype_df.Name.alias("AddressType"),
        #src_person_df.ModifiedDate.alias("PersonModifiedDate"),
        #src_address_df.ModifiedDate.alias("AddressModifiedDate"),
        #src_personaddress_df.ModifiedDate.alias("LinkModifiedDate")
    )
)

(gold_df.write
 .format("delta")
 .mode("overwrite")        # or "append" for incremental
 .option("overwriteSchema", "true")
 .saveAsTable(dst_full_table_name)
)

# COMMAND ----------

