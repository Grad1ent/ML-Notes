# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.types import (
    StructType, StructField,
    IntegerType, StringType, BooleanType, TimestampType
)

# spark = SparkSession.builder.getOrCreate()

# ---- configuration: set catalog/schema/table names ----
dbutils.widgets.text("src_catalog_name", "dbc_diab_stg_eca_aen_bronze_001")
dbutils.widgets.text("src_schema_name", "AdventureWorks")
dbutils.widgets.text("src_table_name", "Person")
dbutils.widgets.text("dst_catalog_name", "dbc_diab_stg_eca_aen_silver_001")
dbutils.widgets.text("dst_schema_name", "AdventureWorks")
dbutils.widgets.text("dst_table_name", "Person")

src_catalog_name = dbutils.widgets.get("src_catalog_name")
src_schema_name = dbutils.widgets.get("src_schema_name")
src_table_name = dbutils.widgets.get("src_table_name")
dst_catalog_name = dbutils.widgets.get("dst_catalog_name")
dst_schema_name = dbutils.widgets.get("dst_schema_name")
dst_table_name = dbutils.widgets.get("dst_table_name")

src_full_table_name = f"{src_catalog_name}.{src_schema_name}.{src_table_name}"
dst_full_table_name = f"{dst_catalog_name}.{dst_schema_name}.{dst_table_name}"


# Read source Delta table
src_df = spark.read.table(src_full_table_name)

#
# QA logic here...
#

(src_df.write
 .format("delta")
 .mode("overwrite")        # or "append" for incremental
 .option("overwriteSchema", "true")
 .saveAsTable(dst_full_table_name)
)

