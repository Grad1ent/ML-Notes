# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.types import (
    StructType, StructField,
    IntegerType, StringType, BooleanType, TimestampType
)

spark = SparkSession.builder.getOrCreate()

# ---- configuration: set catalog/schema/table names ----
dbutils.widgets.text("catalog_name", "dbc_diab_stg_eca_aen_bronze_001")
dbutils.widgets.text("schema_name", "AdventureWorks")
dbutils.widgets.text("table_name", "Address")

catalog_name = dbutils.widgets.get("catalog_name")
schema_name = dbutils.widgets.get("schema_name")
table_name = dbutils.widgets.get("table_name")

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog_name}.{schema_name}")

full_table_name = f"{catalog_name}.{schema_name}.{table_name}"

# ---- define schema consistent with AdventureWorks Person.Person ----
table_schema = StructType([
    StructField("AddressID", IntegerType(), False),
    StructField("AddressLine1", StringType(), True),
    StructField("AddressLine2", StringType(), True),
    StructField("City", StringType(), True),
    StructField("StateProvinceID", IntegerType(), True),
    StructField("PostalCode", StringType(), True),
    # uniqueidentifier -> String (UUID text)    
    StructField("rowguid", StringType(), True),
    StructField("ModifiedDate", TimestampType(), True)
])

# ---- create empty DataFrame and save as Delta table with full catalog.schema.table ----
empty_df = spark.createDataFrame([], table_schema)

# ---- saveAsTable (managed Delta under Unity Catalog)
empty_df.write.format("delta").mode("overwrite").saveAsTable(full_table_name)

# ---- verify ----
spark.sql(f"DESCRIBE EXTENDED {full_table_name}").show(truncate=False)
spark.sql(f"SELECT * FROM {full_table_name} LIMIT 5").show()