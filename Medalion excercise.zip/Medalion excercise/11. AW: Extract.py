# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.types import (
    StructType, StructField,
    IntegerType, StringType, BooleanType, TimestampType
)

# spark = SparkSession.builder.getOrCreate()

# ---- configuration: set catalog/schema/table names ----
dbutils.widgets.text("catalog_name", "dbc_diab_stg_eca_aen_bronze_001")
dbutils.widgets.text("schema_name", "AdventureWorks")
dbutils.widgets.text("table_name", "Person")
dbutils.widgets.text("src_container","upload")
dbutils.widgets.text("src_storage","dlsstgecaaen001")
dbutils.widgets.text("src_folder","AW")
dbutils.widgets.text("src_file","Person Person.csv")

catalog_name = dbutils.widgets.get("catalog_name")
schema_name = dbutils.widgets.get("schema_name")
table_name = dbutils.widgets.get("table_name")
src_container = dbutils.widgets.get("src_container")
src_storage = dbutils.widgets.get("src_storage")
src_folder = dbutils.widgets.get("src_folder")
src_file = dbutils.widgets.get("src_file")
src_location = f"abfss://{src_container}@{src_storage}.dfs.core.windows.net/{src_folder}/{src_file}"

full_table_name = f"{catalog_name}.{schema_name}.{table_name}"

df = (spark.read
      .option("header","true")
      .csv(src_location))

(df.write
 .format("delta")
 .mode("overwrite")
 .option("overwriteSchema","true")
 .saveAsTable(full_table_name))
