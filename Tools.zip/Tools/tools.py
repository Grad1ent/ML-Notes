# Databricks notebook source
dbutils.secrets.listScopes()

# COMMAND ----------

dbutils.secrets.list("dbs-diab-stg-eca-aen-001")

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT metastore_id, metastore_name, cloud, region, global_metastore_id
# MAGIC FROM system.information_schema.metastores;
# MAGIC